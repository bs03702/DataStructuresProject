import pygame
pygame.init()
import main

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
bg = pygame.image.load("HU Map First.jpg")
nodes_pixels ={
    'E-215 Auditorium  ': [200,225],
    'E-220 Tariq Rafi Lecture Theater  ': [475,225],
    'E-221 Film Studio  ': [475,150],
    'C-203 Faculty Pod  ': [400,275],
    'N-200 Faculty Pod  ': [225,375],
    'W-221 Faculty Pod  ': [410,375],
    'C-200 (CPE)  ': [250,275],
    'N-216 Director for Research  ': [225,375],
    'N-217 Director for Research  ': [225,375],
    'N-219 Gulamali Habib Classroom  ': [205,350],
    'N-220 Standard Chartered Classroom  ': [225,325],
    'W-242 Javat Seminar Room  ': [475,350],
    'W-243 Amin Issa Tai Classroom  ': [535,375],
    'W-244 Design Studio  ': [535,405],
    'Baithak  ': [605,375],
    'Mehfil  ': [605,225],
    'Lifts near Auditorium': [215,300],
    'Stairs near Auditorium': [250,250],
    'LB-200 Library First Floor  ': [310,200],
    'Yohsin Hall': [115,200],
    'First floor': [310,300],
    'West Zone 1': [410,355],
    'West Zone 2': [505,375],
    'East Zone': [455,245],
    'North zone': [215,285]
}
def run():
    size = (1280, 475)
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("First Floor")

    carryOn = True

    clock = pygame.time.Clock()

    while carryOn:
        screen.blit(bg, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                carryOn = False

        # Game logic goes here

        for i in nodes_pixels.values():
            pygame.draw.circle(screen, RED, i,4)
        for j in main.A:
            pygame.draw.line(screen, GREEN, nodes_pixels[j[0]], nodes_pixels[j[1]], 3)

        pygame.display.flip()

        clock.tick(30)

    pygame.quit()

