#---------------------------------------------Function Definitions-----------------------------------------------------#
def find_floor(G, nodes):
    floor = {}
    for i in nodes:
        found = False
        for j in G:
            for k in G[j]:
                if i.lower() in k.lower():
                    floor[k] = j
                    found = True
                    break
            if found:
                break
    return floor


def shortest_path(G, start, end):
    visited = []
    parent = {}
    distance = {}
    neighbors = []
    nodes_w_floors = find_floor(G, [start, end])
    s = 0
    for t in nodes_w_floors:
        if s == 0:
            start = t
        if s == 1:
            end = t
        s += 1
    neighbors.append(start)
    parent[start] = None
    distance[start] = 0

    while not len(neighbors) == 0:
        min1 = neighbors[0]
        for i in neighbors:
            if i != min1:
                if distance[i] < distance[min1]:
                    min1 = i
        if min1 == end:
            n = end
            lst = []
            while n != start:
                edge = (parent[n], n, distance[n])
                lst.append(edge)
                n = parent[n]
            return lst[::-1]
        if nodes_w_floors[start] == nodes_w_floors[end]:
            for j in G[nodes_w_floors[start]][min1]:
                if j[0] != start and parent[min1] != j[0]:
                    if j[0] in neighbors:
                        if j[0] in distance and j[1] < distance[j[0]] - distance[min1]:
                            distance[j[0]] = j[1] + distance[min1]
                            parent[j[0]] = min1
                    elif j[0] in visited:
                        if j[0] in distance and j[1] < distance[j[0]] - distance[min1]:
                            distance[j[0]] = j[1] + distance[min1]
                            parent[j[0]] = min1
                    else:
                        distance[j[0]] = j[1] + distance[min1]
                        neighbors.append(j[0])
                        parent[j[0]] = min1
        visited.append(min1)
        neighbors.remove(min1)
    return visited

def addNodes(G, nodes):
    for j in nodes:
        for i in range(len(nodes[j])):
            G[j][nodes[j][i]] = []
    return G


def addEdges(G, edges, directed=False):
    if directed:
        for j in G:
            if j == "Ground" or j == "Lower Ground" or j == "First":
                for i in range(len(edges[j])):
                    G[j][edges[j][i][0]].append([edges[j][i][1], edges[j][i][2]])
    else:
        for j in G:
            if j == "Ground" or j == "Lower Ground" or j == "First":
                for i in range(len(edges[j])):
                    G[j][edges[j][i][0]].append([edges[j][i][1], edges[j][i][2]])
                    G[j][edges[j][i][1]].append([edges[j][i][0], edges[j][i][2]])
    return G


def loadfile(G):
    nodes = {
        "Lower Ground": [],
        "Ground": [],
        "First": [],
        "Second": [],
        "Third": []
    }
    edges = {
        "Lower Ground": [],
        "Ground": [],
        "First": [],
        "Second": [],
        "Third": []
    }
    for floor in G.keys():
        if floor == "Lower Ground":
            f = open("LG_connections.csv")
        elif floor == "Ground":
            f = open("G_connections.csv")
        elif floor == "First":
            f = open("first_connections.csv")
        count = 0
        edge = []
        index_nodes = {}
        for i in f:
            if count == 0:
                node = i.split(",")
                node[-1] = node[-1][:-1]
                n = 1
                for place in node[1:]:
                    if "\n" in place:
                        index_nodes[n] = place[:-1]
                    else:
                        index_nodes[n] = place
                    n += 1
                node = node[1:]
                nodes[floor] = node
            #    print(nodes)
            else:
                a = i.split(",")
                a[-1] = a[-1][:-1]
                index = 1
                for j in a[1:]:
                    if "\n" in j:
                        j = j[:-1]
                    if j != "-1" and j != "0":
                        e = (index_nodes[count], index_nodes[index], int(j))
                        edge.append(e)
                    index += 1
            count += 1
        edges[floor] = edge
        addNodes(G, nodes)
        addEdges(G, edges, True)
    return G


Map = {
    "Lower Ground": {},
    "Ground": {},
    "First": {},
    "Second": {},
    "Third": {}
}
# Ask user for their current location / nearest landmark
start = input("Enter current location/ nearest landmark: ")
# Ask user for destination
end = input("Enter destination: ")

loadfile(Map)
A = shortest_path(Map,start,end)
