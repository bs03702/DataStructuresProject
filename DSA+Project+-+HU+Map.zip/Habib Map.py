import pygame
pygame.init()
import main
import LG_visuals
import G_visuals
import First_visuals


file_to_run = {"Lower Ground": "LG_visuals.run()",
              "Ground": "G_visuals.run()",
              "First": "First_visuals.run()"}
floors = main.find_floor(main.Map, [main.start, main.end])
for i in floors:
    eval(file_to_run[floors[i]])
    break
