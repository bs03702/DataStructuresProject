import pygame
pygame.init()
import main

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
bg = pygame.image.load("HU Map G.jpg")
nodes_pixels = {'Atrium/Reception': [300,250],
                'E-100 Agha Multipurpose Hall': [275,200],
                'LB-100 Library and Information Commons': [350,175],
                'SC-100 Student Centre': [300,280],
                'Career Office': [275,280],
                'Cafe To Go': [375,175],
                'E-101 Cassim Computing Lab': [420,150],
                'E-105 Faculty Pod': [475,150],
                'Wellness Centre': [375,350],
                'C-100 Faculty Pod': [480,275],
                'C-109 Arif Habib Classroom': [550,300],
                'W-110 Adamjee Math Lab': [485,350],
                'W-100 Physics Lab': [435,350],
                'W-118 Chemistry(Energy) Lab': [675,350],
                'W-121 Ecology(Energy) Lab':[675,400],
                'W-114 Digital Systems And Instrumentation Lab': [590,390],
                'C-110 Student Lounge': [700,290],
                'E-121 Soorty Lecture Theater': [650,200],
                'C-114 Faculty Pod': [750,290],
                'W-111 Communication Lab': [590,350],
                'Central Street 1': [400,240],
                'Central Street 2': [520,240],
                'East Street': [650,240],
                'Wellness Courtyard': [380,320],
                'Lift 1': [285,295],
                'Lift 2': [460,365],
                'Councelling Suite': [360,295],
                'Academic Courtyard 1': [520,325],
                'Academic Courtyard 2': [640,325],
                'HU Clinic': [380,345],
                'Gate 2': [125,225],
                'Gate 1': [110,345],
                'Library lift': [305,180],
                'Habib Metro Bank': [205,365]
    }

def run():
    size = (1280, 475)
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("Ground Floor")

    carryOn = True

    clock = pygame.time.Clock()

    while carryOn:
        screen.blit(bg, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                carryOn = False

        # Game logic goes here

        for i in nodes_pixels.values():
            pygame.draw.circle(screen, RED,i,4)
        for j in main.A:
            pygame.draw.line(screen, GREEN, nodes_pixels[j[0]], nodes_pixels[j[1]], 3)

        pygame.display.flip()

        clock.tick(30)

    pygame.quit()
