import pygame
pygame.init()
import main

#A = main.A

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
bg = pygame.image.load("HU Map LG.jpg")
nodes_pixels ={
    'Zen Garden': [925,215],
    'Sports Courts': [890,215],
    'Malang Cafe (Dhaba)': [625,185],
    'E-017 Habib Dukaan': [590,215],
    'E-013 Tapal Cafeteria': [500,200],
    'Amphitheater': [550,275],
    'Library Lift': [230,185],
    'C-025 Engineering Workshop': [490,300],
    'Cafeteria Courtyard': [570,222],
    'C-017 C-018 Gym': [725,315],
    'Swimming Pool': [725,350],
    'C-015 Classroom': [635,250],
    'C-004 Power Lab': [400,250],
    'East Lower Ground': [365,175],
    'C-001 Electronic and Circuit Lab': [375,250],
    'E-003 Linux and Networking Lab': [350,160],
    'Central - Lower Ground': [315,225],
    'E-010 Visualization and Graphics Lab': [410,150],
    'E-011 Dinshaw Seminar Room': [450,140],
    'E-012 Rangoonwala Classroom': [475,140],
    'C-007 Projects Lab': [475,250],
    'E-002 Media Mock-up Studio': [350,175],
    'C-023 Head of Adminstration and Safety Offices': [635,300],
    'C-022 Administration and Safety Offices': [635,315],
    'LB-001 EHSAS': [210,180],
    'W-004 ': [490,350],
    'W-007 Lost and Found Office':[550,375],
    'Car Parking': [275,225],
    'Lift 2': [525,375]
}
def run():
    size = (1280, 475)
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("Lower Ground Floor")

    carryOn = True

    clock = pygame.time.Clock()

    while carryOn:
        screen.blit(bg, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                carryOn = False

        # Game logic goes here

        for i in nodes_pixels.values():
            pygame.draw.circle(screen, RED,i,4)
        for j in main.A:
            pygame.draw.line(screen, GREEN, nodes_pixels[j[0]], nodes_pixels[j[1]], 3)

        pygame.display.flip()

        clock.tick(30)

    pygame.quit()
